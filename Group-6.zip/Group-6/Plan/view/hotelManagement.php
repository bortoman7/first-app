<?php 
require_once('../controller/sessionCheck.php');
require_once('../view/header.php')

?>
  <html lang="en">
   <head>
	
	<title>Hotel Management</title>
   </head>
   <body>
	
   
    <center>
	<a href="../controller/showProfile.php">Profile</a> <br>
	<br/>
	<a href="changePass.php">Change Password</a> <br>
	<br>
	<a href="..//controller/addHotelRoom.php">ADD HOTEL Rooms</a> <br>
	<br/>
	<a href="..//controller/showAllRooms.php">Show ALL rooms</a> <br>
	
	
</center>


</body>
   </html>