<?php

 require_once('db.php');


function insertReview($username, $rating, $review, $serviceType) {
    $con = getConnection();

    $sql = "INSERT INTO reviews (username, rating, review, service_type, created_at) 
            VALUES ('$username', $rating, '$review', '$serviceType', NOW())";

    if (mysqli_query($con, $sql)) {
        mysqli_close($con);
        return "Your review has been submitted.";
    } else {
        mysqli_close($con);
        return "Failed to submit the review. Please try again later.";
    }
}

function getAllReviews() {
    $con = getConnection();

    $sql = "SELECT * FROM reviews";
    $result = mysqli_query($con, $sql);
    $reviews = array();

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $reviews[] = $row;
        }
    }

    mysqli_close($con);

    return $reviews;
}
?>
